import { content } from '@/content/tyv';

export type Listing = {
  id: number | string;
  title: string;
  description: string;
  price: number;
  location: string;
  categorySlug: string;
  subcategorySlug: string;
  image: string;
  sellerName: string;
  datePosted: string;
  updatedAt?: string;
  ownerId?: string;
  isOwnedByViewer?: boolean;
  viewerOwnershipUnavailable?: boolean;
  transactionType?: 'sale' | 'rent';
  propertyType?: 'apartments' | 'land' | 'commercial' | 'storage';
  marketplaceType?: string;
  images?: ListingImage[];
  status?: ListingStatus;
};

export type ListingImage = {
  id: string;
  url: string;
  position: number;
  storagePath?: string;
};

export type ListingStatus = 'active' | 'reserved' | 'sold' | 'archived';

export const LISTING_STATUSES: ListingStatus[] = [
  'active',
  'reserved',
  'sold',
  'archived',
];

export function isListingStatus(value: unknown): value is ListingStatus {
  return (
    value === 'active' ||
    value === 'reserved' ||
    value === 'sold' ||
    value === 'archived'
  );
}

export function getListingStatus(listing: Listing): ListingStatus {
  return isListingStatus(listing.status) ? listing.status : 'active';
}

export const LOCAL_LISTING_PLACEHOLDER_IMAGE =
  'https://img.magnific.com/free-photo/hands-holding-colorful-paper-bags_1301-1750.jpg?semt=ais_hybrid&w=740&q=80';

export function formatListingPrice(price: number): string {
  if (price === 0) {
    return content.freePriceLabel;
  }

  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    maximumFractionDigits: 0,
  }).format(price);
}

export const listings: Listing[] = [
  {
    id: 1,
    title: 'Eski telefolun',
    description: 'A used phone in working condition with charger included.',
    price: 2500,
    location: 'Kyzyl',
    categorySlug: 'marketplace',
    subcategorySlug: 'buy',
    marketplaceType: 'used',
    image: 'https://img.magnific.com/free-photo/hands-holding-colorful-paper-bags_1301-1750.jpg?semt=ais_hybrid&w=740&q=80',
    sellerName: 'Demo Seller',
    datePosted: '2026-08-01',
  },
  {
    id: 2,
    title: 'Bisiklet',
    description: 'City bicycle with a comfortable seat and good tires.',
    price: 5000,
    location: 'Turan',
    categorySlug: 'marketplace',
    subcategorySlug: 'buy',
    marketplaceType: 'used',
    image: 'https://img.magnific.com/free-photo/hands-holding-colorful-paper-bags_1301-1750.jpg?semt=ais_hybrid&w=740&q=80',
    sellerName: 'Demo Seller',
    datePosted: '2026-08-02',
  },
  {
    id: 3,
    title: 'Kitepter',
    description: 'Small set of books for home reading and study.',
    price: 800,
    location: 'Kyzyl',
    categorySlug: 'marketplace',
    subcategorySlug: 'buy',
    marketplaceType: 'books',
    image: 'https://img.magnific.com/free-photo/hands-holding-colorful-paper-bags_1301-1750.jpg?semt=ais_hybrid&w=740&q=80',
    sellerName: 'Demo Seller',
    datePosted: '2026-08-02',
  },
  {
    id: 4,
    title: 'Kulung',
    description: 'Pet listing for a young animal. Contact seller for details.',
    price: 15000,
    location: 'Ak-Dovurak',
    categorySlug: 'marketplace',
    subcategorySlug: 'buy',
    marketplaceType: 'pets',
    image: 'https://img.magnific.com/free-photo/hands-holding-colorful-paper-bags_1301-1750.jpg?semt=ais_hybrid&w=740&q=80',
    sellerName: 'Demo Seller',
    datePosted: '2026-08-03',
  },
  {
    id: 5,
    title: 'Calas masinaazy',
    description: 'Used car listing with basic maintenance completed.',
    price: 120000,
    location: 'Shagonar',
    categorySlug: 'auto',
    subcategorySlug: 'used-cars',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNiayatpD8qI7wUIdvwvJfRkg1nu4KXaPcx4wEMNy3xORNRTc3Lv0HbgA&s=10',
    sellerName: 'Demo Auto',
    datePosted: '2026-08-03',
  },
  {
    id: 6,
    title: 'Evge shalyk',
    description: 'Useful home item in clean condition.',
    price: 3500,
    location: 'Kyzyl',
    categorySlug: 'marketplace',
    subcategorySlug: 'buy',
    marketplaceType: 'home-goods',
    image: 'https://img.magnific.com/free-photo/hands-holding-colorful-paper-bags_1301-1750.jpg?semt=ais_hybrid&w=740&q=80',
    sellerName: 'Demo Seller',
    datePosted: '2026-08-04',
  },
  {
    id: 101,
    title: 'Apartments Sale Listing',
    description: 'Apartment for sale near shops and public transport.',
    price: 7800000,
    location: 'City Center',
    categorySlug: 'housing',
    subcategorySlug: 'sale',
    transactionType: 'sale',
    propertyType: 'apartments',
    image: 'https://i.pinimg.com/736x/60/4f/7c/604f7c17e5d21acde28ee1c793b163b4.jpg',
    sellerName: 'Housing Demo',
    datePosted: '2026-07-28',
  },
  {
    id: 102,
    title: 'Apartments Rent Listing',
    description: 'Apartment for rent with one bedroom and a bright kitchen.',
    price: 64000,
    location: 'Downtown',
    categorySlug: 'housing',
    subcategorySlug: 'rent',
    transactionType: 'rent',
    propertyType: 'apartments',
    image: 'https://i.pinimg.com/736x/60/4f/7c/604f7c17e5d21acde28ee1c793b163b4.jpg',
    sellerName: 'Housing Demo',
    datePosted: '2026-07-29',
  },
  {
    id: 103,
    title: 'Land Sale Listing',
    description: 'Land plot for sale with road access.',
    price: 2200000,
    location: 'Westside',
    categorySlug: 'housing',
    subcategorySlug: 'sale',
    transactionType: 'sale',
    propertyType: 'land',
    image: 'https://i.pinimg.com/736x/60/4f/7c/604f7c17e5d21acde28ee1c793b163b4.jpg',
    sellerName: 'Housing Demo',
    datePosted: '2026-07-30',
  },
  {
    id: 104,
    title: 'Land Rent Listing',
    description: 'Land available for short-term rent.',
    price: 31000,
    location: 'Riverside',
    categorySlug: 'housing',
    subcategorySlug: 'rent',
    transactionType: 'rent',
    propertyType: 'land',
    image: 'https://i.pinimg.com/736x/60/4f/7c/604f7c17e5d21acde28ee1c793b163b4.jpg',
    sellerName: 'Housing Demo',
    datePosted: '2026-07-31',
  },
  {
    id: 105,
    title: 'Commercial Sale Listing',
    description: 'Commercial space for sale in an active business area.',
    price: 14500000,
    location: 'Business District',
    categorySlug: 'housing',
    subcategorySlug: 'sale',
    transactionType: 'sale',
    propertyType: 'commercial',
    image: 'https://i.pinimg.com/736x/60/4f/7c/604f7c17e5d21acde28ee1c793b163b4.jpg',
    sellerName: 'Housing Demo',
    datePosted: '2026-08-01',
  },
  {
    id: 106,
    title: 'Commercial Rent Listing',
    description: 'Commercial unit for rent with street-facing windows.',
    price: 125000,
    location: 'Market Street',
    categorySlug: 'housing',
    subcategorySlug: 'rent',
    transactionType: 'rent',
    propertyType: 'commercial',
    image: 'https://i.pinimg.com/736x/60/4f/7c/604f7c17e5d21acde28ee1c793b163b4.jpg',
    sellerName: 'Housing Demo',
    datePosted: '2026-08-01',
  },
  {
    id: 107,
    title: 'Garages / parking Sale Listing',
    description: 'Garage space for sale in a convenient block.',
    price: 950000,
    location: 'North Block',
    categorySlug: 'housing',
    subcategorySlug: 'sale',
    transactionType: 'sale',
    propertyType: 'storage',
    image: 'https://i.pinimg.com/736x/60/4f/7c/604f7c17e5d21acde28ee1c793b163b4.jpg',
    sellerName: 'Housing Demo',
    datePosted: '2026-08-02',
  },
  {
    id: 108,
    title: 'Garages / parking Rent Listing',
    description: 'Parking space for monthly rent near the station.',
    price: 18000,
    location: 'Station Area',
    categorySlug: 'housing',
    subcategorySlug: 'rent',
    transactionType: 'rent',
    propertyType: 'storage',
    image: 'https://i.pinimg.com/736x/60/4f/7c/604f7c17e5d21acde28ee1c793b163b4.jpg',
    sellerName: 'Housing Demo',
    datePosted: '2026-08-02',
  },
  {
    id: 201,
    title: 'Winter coat',
    description: 'Warm coat in good condition.',
    price: 4200,
    location: 'Kyzyl',
    categorySlug: 'marketplace',
    subcategorySlug: 'buy',
    marketplaceType: 'clothing',
    image: 'https://img.magnific.com/free-photo/hands-holding-colorful-paper-bags_1301-1750.jpg?semt=ais_hybrid&w=740&q=80',
    sellerName: 'Demo Seller',
    datePosted: '2026-08-04',
  },
  {
    id: 202,
    title: 'Office notebooks',
    description: 'New notebooks and stationery for school or office.',
    price: 600,
    location: 'Kyzyl',
    categorySlug: 'marketplace',
    subcategorySlug: 'buy',
    marketplaceType: 'office',
    image: 'https://img.magnific.com/free-photo/hands-holding-colorful-paper-bags_1301-1750.jpg?semt=ais_hybrid&w=740&q=80',
    sellerName: 'Demo Seller',
    datePosted: '2026-08-05',
  },
  {
    id: 203,
    title: 'Free kids toys',
    description: 'Small toys available for pickup.',
    price: 0,
    location: 'Kyzyl',
    categorySlug: 'marketplace',
    subcategorySlug: 'free',
    marketplaceType: 'kids',
    image: 'https://img.magnific.com/free-photo/hands-holding-colorful-paper-bags_1301-1750.jpg?semt=ais_hybrid&w=740&q=80',
    sellerName: 'Demo Seller',
    datePosted: '2026-08-05',
  },
  {
    id: 204,
    title: 'Looking for construction materials',
    description: 'Wanted: leftover boards, screws, and repair materials.',
    price: 1000,
    location: 'Turan',
    categorySlug: 'marketplace',
    subcategorySlug: 'wanted',
    marketplaceType: 'construction materials',
    image: 'https://img.magnific.com/free-photo/hands-holding-colorful-paper-bags_1301-1750.jpg?semt=ais_hybrid&w=740&q=80',
    sellerName: 'Demo Seller',
    datePosted: '2026-08-05',
  },
  {
    id: 301,
    title: 'New small car',
    description: 'New compact car available from a demo seller.',
    price: 900000,
    location: 'Kyzyl',
    categorySlug: 'auto',
    subcategorySlug: 'new-cars',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNiayatpD8qI7wUIdvwvJfRkg1nu4KXaPcx4wEMNy3xORNRTc3Lv0HbgA&s=10',
    sellerName: 'Demo Auto',
    datePosted: '2026-08-01',
  },
  {
    id: 302,
    title: 'Auto parts set',
    description: 'Set of basic auto parts for repair work.',
    price: 12000,
    location: 'Kyzyl',
    categorySlug: 'auto',
    subcategorySlug: 'auto-parts',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNiayatpD8qI7wUIdvwvJfRkg1nu4KXaPcx4wEMNy3xORNRTc3Lv0HbgA&s=10',
    sellerName: 'Demo Auto',
    datePosted: '2026-08-02',
  },
  {
    id: 303,
    title: 'Car rental',
    description: 'Daily car rental for local trips.',
    price: 3500,
    location: 'Kyzyl',
    categorySlug: 'auto',
    subcategorySlug: 'rent',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNiayatpD8qI7wUIdvwvJfRkg1nu4KXaPcx4wEMNy3xORNRTc3Lv0HbgA&s=10',
    sellerName: 'Demo Auto',
    datePosted: '2026-08-02',
  },
  {
    id: 401,
    title: 'Electrician available',
    description: 'Experienced electrician available for small repairs.',
    price: 2500,
    location: 'Kyzyl',
    categorySlug: 'services',
    subcategorySlug: 'all',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTmNvUIaYKZU050ccPlwlNI81Jl4QOggi9Qa7cjZDgoaBs0_Lm7fqe4bH4&s=10',
    sellerName: 'Service Demo',
    datePosted: '2026-08-03',
  },
  {
    id: 501,
    title: 'Designer looking for work',
    description: 'Designer available for part-time projects.',
    price: 0,
    location: 'Kyzyl',
    categorySlug: 'jobs',
    subcategorySlug: 'find-jobs',
    image: 'https://thumbs.dreamstime.com/b/none-282600526.jpg',
    sellerName: 'Jobs Demo',
    datePosted: '2026-08-03',
  },
  {
    id: 502,
    title: 'Need a cafe worker',
    description: 'Cafe is looking for a responsible worker.',
    price: 45000,
    location: 'Kyzyl',
    categorySlug: 'jobs',
    subcategorySlug: 'find-talents',
    image: 'https://thumbs.dreamstime.com/b/none-282600526.jpg',
    sellerName: 'Jobs Demo',
    datePosted: '2026-08-04',
  },
  {
    id: 601,
    title: 'Weekend event',
    description: 'Small community event this weekend.',
    price: 500,
    location: 'Kyzyl',
    categorySlug: 'events',
    subcategorySlug: 'events',
    image: '/images/party.png',
    sellerName: 'Events Demo',
    datePosted: '2026-08-04',
  },
  {
    id: 602,
    title: 'Night club table',
    description: 'Table reservation offer for a night club.',
    price: 3000,
    location: 'Kyzyl',
    categorySlug: 'events',
    subcategorySlug: 'night-clubs',
    image: '/images/party.png',
    sellerName: 'Events Demo',
    datePosted: '2026-08-05',
  },
  {
    id: 603,
    title: 'Lost keys',
    description: 'Keys were lost near the central square.',
    price: 0,
    location: 'Kyzyl',
    categorySlug: 'events',
    subcategorySlug: 'lost-found',
    image: '/images/party.png',
    sellerName: 'Events Demo',
    datePosted: '2026-08-05',
  },
];
