'use client';

import type { AuthError, User } from '@supabase/supabase-js';
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { createClient } from '@/lib/supabase/client';
import {
  getRealtimeDiagnostics,
  logRealtimeDiagnostic,
} from '@/lib/supabase/realtimeDiagnostics';
import {
  PROFILE_BIO_MAX_LENGTH,
  PROFILE_LOCATION_MAX_LENGTH,
  isValidProfileDisplayName,
  sanitizeProfileDisplayName,
  sanitizeOptionalProfileText,
  type AppProfile,
  type AppUser,
  type AuthStatus,
  type ProfileStatus,
} from '@/lib/auth/types';

type AuthFailureReason =
  | 'invalid-credentials'
  | 'email-not-confirmed'
  | 'rate-limited'
  | 'network'
  | 'unknown';

type SignInResult =
  | { ok: true }
  | { ok: false; reason: AuthFailureReason };

type SignUpResult =
  | { ok: true; requiresEmailConfirmation: boolean }
  | { ok: false; reason: AuthFailureReason };

type ProfileUpdateResult =
  | { ok: true; user: AppUser; profile: AppProfile }
  | {
      ok: false;
      reason: 'invalid-display-name' | 'invalid-profile-details' | 'unable-to-update';
    };

type ProfileUpdateValues = {
  displayName: string;
  bio: string;
  location: string;
};

type AuthContextValue = {
  status: AuthStatus;
  profileStatus: ProfileStatus;
  user: AppUser | null;
  profile: AppProfile | null;
  refreshAuth: () => Promise<void>;
  signOut: () => Promise<void>;
  updateProfile: (values: ProfileUpdateValues) => Promise<ProfileUpdateResult>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

type ResolvedAuthState = {
  status: AuthStatus;
  profileStatus: ProfileStatus;
  user: AppUser | null;
  profile: AppProfile | null;
};

let cachedAuthState: ResolvedAuthState | null = null;

function isProfileRow(value: unknown): value is {
  id: string;
  display_name: string;
  public_slug: string;
  bio: string | null;
  location: string | null;
  avatar_path: string | null;
  avatar_focus_x: number;
  avatar_focus_y: number;
  avatar_zoom: number;
  created_at: string;
  updated_at: string;
} {
  if (!value || typeof value !== 'object') {
    return false;
  }

  const profile = value as Partial<{
    id: unknown;
    display_name: unknown;
    public_slug: unknown;
    bio: unknown;
    location: unknown;
    avatar_path: unknown;
    avatar_focus_x: unknown;
    avatar_focus_y: unknown;
    avatar_zoom: unknown;
    created_at: unknown;
    updated_at: unknown;
  }>;

  return (
    typeof profile.id === 'string' &&
    typeof profile.display_name === 'string' &&
    typeof profile.public_slug === 'string' &&
    (profile.bio === null || typeof profile.bio === 'string') &&
    (profile.location === null || typeof profile.location === 'string') &&
    (profile.avatar_path === null || typeof profile.avatar_path === 'string') &&
    typeof profile.avatar_focus_x === 'number' &&
    typeof profile.avatar_focus_y === 'number' &&
    typeof profile.avatar_zoom === 'number' &&
    typeof profile.created_at === 'string' &&
    typeof profile.updated_at === 'string'
  );
}

function mapProfile(profile: {
  id: string;
  display_name: string;
  public_slug: string;
  bio: string | null;
  location: string | null;
  avatar_path: string | null;
  avatar_focus_x: number;
  avatar_focus_y: number;
  avatar_zoom: number;
  created_at: string;
  updated_at: string;
}): AppProfile {
  return {
    id: profile.id,
    displayName: profile.display_name,
    publicSlug: profile.public_slug,
    bio: profile.bio,
    location: profile.location,
    avatarPath: profile.avatar_path,
    avatarFocusX: profile.avatar_focus_x,
    avatarFocusY: profile.avatar_focus_y,
    avatarZoom: profile.avatar_zoom,
    createdAt: profile.created_at,
    updatedAt: profile.updated_at,
  };
}

function mapAppUser(user: User, profile: AppProfile): AppUser | null {
  const email = user.email?.trim();

  if (!email || user.id !== profile.id) {
    return null;
  }

  return {
    id: user.id,
    email,
    displayName: profile.displayName,
  };
}

function classifyAuthError(error: AuthError | Error | null): AuthFailureReason {
  if (!error) {
    return 'unknown';
  }

  const message = error.message.toLocaleLowerCase();
  const code = 'code' in error && typeof error.code === 'string'
    ? error.code.toLocaleLowerCase()
    : '';
  const status = 'status' in error && typeof error.status === 'number'
    ? error.status
    : undefined;

  if (
    code.includes('email_not_confirmed') ||
    message.includes('email not confirmed') ||
    message.includes('confirm')
  ) {
    return 'email-not-confirmed';
  }

  if (
    status === 429 ||
    code.includes('rate') ||
    message.includes('rate limit') ||
    message.includes('too many')
  ) {
    return 'rate-limited';
  }

  if (
    code.includes('invalid_credentials') ||
    message.includes('invalid login') ||
    message.includes('invalid credentials')
  ) {
    return 'invalid-credentials';
  }

  if (
    message.includes('failed to fetch') ||
    message.includes('network') ||
    message.includes('fetch')
  ) {
    return 'network';
  }

  return 'unknown';
}

async function loadProfile(userId: string): Promise<AppProfile | null> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from('profiles')
    .select('id, display_name, public_slug, bio, location, avatar_path, avatar_focus_x, avatar_focus_y, avatar_zoom, created_at, updated_at')
    .eq('id', userId)
    .maybeSingle();

  if (error || !isProfileRow(data)) {
    return null;
  }

  return mapProfile(data);
}

async function resolveCurrentAuthState(): Promise<{
  status: AuthStatus;
  profileStatus: ProfileStatus;
  user: AppUser | null;
  profile: AppProfile | null;
}> {
  const supabase = createClient();
  const { data, error } = await supabase.auth.getUser();

  if (error || !data.user) {
    return {
      status: 'unauthenticated',
      profileStatus: 'idle',
      user: null,
      profile: null,
    };
  }

  const profile = await loadProfile(data.user.id);
  const appUser = profile ? mapAppUser(data.user, profile) : null;

  if (!profile || !appUser) {
    return {
      status: 'authenticated',
      profileStatus: 'error',
      user: null,
      profile: null,
    };
  }

  return {
    status: 'authenticated',
    profileStatus: 'loaded',
    user: appUser,
    profile,
  };
}

export async function signInWithEmailPassword(
  email: string,
  password: string
): Promise<SignInResult> {
  try {
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      return { ok: false, reason: classifyAuthError(error) };
    }

    return { ok: true };
  } catch (error) {
    return {
      ok: false,
      reason: classifyAuthError(error instanceof Error ? error : null),
    };
  }
}

export async function signUpWithEmailPassword({
  displayName,
  email,
  password,
  nextPath,
}: {
  displayName: string;
  email: string;
  password: string;
  nextPath: string;
}): Promise<SignUpResult> {
  try {
    const supabase = createClient();
    const origin = window.location.origin;
    const callbackUrl = new URL('/auth/callback', origin);

    callbackUrl.searchParams.set('next', nextPath);

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          display_name: displayName,
        },
        emailRedirectTo: callbackUrl.toString(),
      },
    });

    if (error) {
      return { ok: false, reason: classifyAuthError(error) };
    }

    return {
      ok: true,
      requiresEmailConfirmation: !data.session,
    };
  } catch (error) {
    return {
      ok: false,
      reason: classifyAuthError(error instanceof Error ? error : null),
    };
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const supabase = useMemo(() => createClient(), []);
  const [status, setStatus] = useState<AuthStatus>(
    cachedAuthState?.status || 'checking'
  );
  const [profileStatus, setProfileStatus] = useState<ProfileStatus>(
    cachedAuthState?.profileStatus || 'idle'
  );
  const [user, setUser] = useState<AppUser | null>(cachedAuthState?.user || null);
  const [profile, setProfile] = useState<AppProfile | null>(
    cachedAuthState?.profile || null
  );
  const statusRef = useRef(status);
  const userIdRef = useRef(user?.id || null);

  const refreshAuth = useCallback(async () => {
    if (!cachedAuthState) {
      setStatus('checking');
      setProfileStatus('loading');
    }

    const nextState = await resolveCurrentAuthState();

    setStatus(nextState.status);
    setProfileStatus(nextState.profileStatus);
    setUser(nextState.user);
    setProfile(nextState.profile);
    cachedAuthState = nextState;
  }, []);

  useEffect(() => {
    statusRef.current = status;
    userIdRef.current = user?.id || null;
  }, [status, user?.id]);

  useEffect(() => {
    let active = true;

    logRealtimeDiagnostic('auth-provider-effect-start', {
      owner: 'auth-provider',
      authStatus: statusRef.current,
      authUserId: userIdRef.current,
      ...getRealtimeDiagnostics(supabase),
    });

    async function refreshIfActive(): Promise<void> {
      if (!active) {
        return;
      }

      await refreshAuth();
    }

    void refreshIfActive();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      logRealtimeDiagnostic('auth-provider-auth-state-change', {
        owner: 'auth-provider',
        event,
        sessionUserId: session?.user?.id || null,
        hasSessionAccessToken: Boolean(session?.access_token),
        ...getRealtimeDiagnostics(supabase),
      });
      window.setTimeout(() => {
        void refreshIfActive();
      }, 0);
    });

    return () => {
      active = false;
      logRealtimeDiagnostic('auth-provider-effect-cleanup', {
        owner: 'auth-provider',
        ...getRealtimeDiagnostics(supabase),
      });
      subscription.unsubscribe();
    };
  }, [refreshAuth, supabase]);

  async function signOut(): Promise<void> {
    await supabase.auth.signOut();
    setStatus('unauthenticated');
    setProfileStatus('idle');
    setUser(null);
    setProfile(null);
    cachedAuthState = {
      status: 'unauthenticated',
      profileStatus: 'idle',
      user: null,
      profile: null,
    };
  }

  async function updateProfile(
    values: ProfileUpdateValues
  ): Promise<ProfileUpdateResult> {
    const safeDisplayName = sanitizeProfileDisplayName(values.displayName);
    const trimmedBio = values.bio.trim();
    const trimmedLocation = values.location.trim();
    const safeBio = sanitizeOptionalProfileText(
      values.bio,
      PROFILE_BIO_MAX_LENGTH
    );
    const safeLocation = sanitizeOptionalProfileText(
      values.location,
      PROFILE_LOCATION_MAX_LENGTH
    );

    if (!isValidProfileDisplayName(safeDisplayName) || !user) {
      return { ok: false, reason: 'invalid-display-name' };
    }

    if (
      trimmedBio.length > PROFILE_BIO_MAX_LENGTH ||
      trimmedLocation.length > PROFILE_LOCATION_MAX_LENGTH
    ) {
      return { ok: false, reason: 'invalid-profile-details' };
    }

    const { data, error } = await supabase
      .from('profiles')
      .update({
        display_name: safeDisplayName,
        bio: safeBio,
        location: safeLocation,
      })
      .eq('id', user.id)
      .select('id, display_name, public_slug, bio, location, avatar_path, avatar_focus_x, avatar_focus_y, avatar_zoom, created_at, updated_at')
      .single();

    if (error || !isProfileRow(data)) {
      return { ok: false, reason: 'unable-to-update' };
    }

    const nextProfile = mapProfile(data);
    const nextUser = {
      ...user,
      displayName: nextProfile.displayName,
    };

    setProfile(nextProfile);
    setUser(nextUser);
    cachedAuthState = cachedAuthState
      ? {
          ...cachedAuthState,
          user: nextUser,
          profile: nextProfile,
        }
      : null;

    return { ok: true, user: nextUser, profile: nextProfile };
  }

  const value: AuthContextValue = {
    status,
    profileStatus,
    user,
    profile,
    refreshAuth,
    signOut,
    updateProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuthStatus(): AuthContextValue {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error('useAuthStatus must be used within AuthProvider.');
  }

  return context;
}
