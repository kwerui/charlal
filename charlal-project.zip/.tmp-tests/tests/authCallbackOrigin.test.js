"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strict_1 = __importDefault(require("node:assert/strict"));
const node_test_1 = __importDefault(require("node:test"));
const callbackOrigin_js_1 = require("../src/lib/auth/callbackOrigin.js");
(0, node_test_1.default)('uses NEXT_PUBLIC_SITE_URL as the production auth callback origin', () => {
    strict_1.default.equal((0, callbackOrigin_js_1.getAuthCallbackRedirectOrigin)({
        nodeEnv: 'production',
        requestOrigin: 'https://attacker.example',
        siteUrl: 'https://charlal.example/account?ignored=1',
    }), 'https://charlal.example');
});
(0, node_test_1.default)('requires NEXT_PUBLIC_SITE_URL in production', () => {
    strict_1.default.throws(() => (0, callbackOrigin_js_1.getAuthCallbackRedirectOrigin)({
        nodeEnv: 'production',
        requestOrigin: 'https://charlal.example',
        siteUrl: '',
    }), /NEXT_PUBLIC_SITE_URL/);
});
(0, node_test_1.default)('does not accept an invalid production NEXT_PUBLIC_SITE_URL', () => {
    strict_1.default.throws(() => (0, callbackOrigin_js_1.getAuthCallbackRedirectOrigin)({
        nodeEnv: 'production',
        requestOrigin: 'https://charlal.example',
        siteUrl: 'javascript:alert(1)',
    }), /NEXT_PUBLIC_SITE_URL/);
});
(0, node_test_1.default)('falls back to the request origin outside production', () => {
    strict_1.default.equal((0, callbackOrigin_js_1.getAuthCallbackRedirectOrigin)({
        nodeEnv: 'development',
        requestOrigin: 'http://localhost:3000',
        siteUrl: '',
    }), 'http://localhost:3000');
});
