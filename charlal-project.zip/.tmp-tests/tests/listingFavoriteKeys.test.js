"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strict_1 = __importDefault(require("node:assert/strict"));
const node_test_1 = __importDefault(require("node:test"));
const listingFavoriteKeys_js_1 = require("../src/lib/listingFavoriteKeys.js");
function createListing(id, overrides = {}) {
    return {
        id,
        title: `Listing ${id}`,
        description: `Description ${id}`,
        price: 100,
        location: 'Kyzyl',
        categorySlug: 'marketplace',
        subcategorySlug: 'buy',
        marketplaceType: 'used',
        image: 'https://example.com/listing.jpg',
        sellerName: 'Seller',
        datePosted: '2026-08-18',
        ...overrides,
    };
}
(0, node_test_1.default)('returns no database listing ids for empty favorites', () => {
    strict_1.default.deepEqual((0, listingFavoriteKeys_js_1.getDatabaseListingIdsFromFavorites)([]), []);
});
(0, node_test_1.default)('classifies database and builtin favorite references from listing ids', () => {
    strict_1.default.deepEqual((0, listingFavoriteKeys_js_1.getListingFavoriteReference)(createListing('db-abc')), {
        source: 'database',
        listingId: 'db-abc',
    });
    strict_1.default.deepEqual((0, listingFavoriteKeys_js_1.getListingFavoriteReference)(createListing(42)), {
        source: 'builtin',
        listingId: '42',
    });
    strict_1.default.equal((0, listingFavoriteKeys_js_1.getListingFavoriteReference)(createListing('local-draft')), null);
});
(0, node_test_1.default)('extracts unique database listing ids from favorites in saved order', () => {
    const favorites = [
        {
            source: 'builtin',
            listingId: '1',
            createdAt: '2026-08-18T12:00:00.000Z',
        },
        {
            source: 'database',
            listingId: ' db-listing-2 ',
            createdAt: '2026-08-18T11:00:00.000Z',
        },
        {
            source: 'database',
            listingId: 'db-listing-1',
            createdAt: '2026-08-18T10:00:00.000Z',
        },
        {
            source: 'database',
            listingId: 'db-listing-2',
            createdAt: '2026-08-18T09:00:00.000Z',
        },
    ];
    strict_1.default.deepEqual((0, listingFavoriteKeys_js_1.getDatabaseListingIdsFromFavorites)(favorites), [
        'db-listing-2',
        'db-listing-1',
    ]);
});
(0, node_test_1.default)('builds saved listings in favorite order and omits inaccessible listings', () => {
    const favorites = [
        {
            source: 'database',
            listingId: 'db-visible-2',
            createdAt: '2026-08-18T12:00:00.000Z',
        },
        {
            source: 'builtin',
            listingId: '7',
            createdAt: '2026-08-18T11:00:00.000Z',
        },
        {
            source: 'database',
            listingId: 'db-deleted',
            createdAt: '2026-08-18T10:00:00.000Z',
        },
        {
            source: 'database',
            listingId: 'db-owned',
            createdAt: '2026-08-18T09:00:00.000Z',
        },
        {
            source: 'database',
            listingId: 'db-visible-1',
            createdAt: '2026-08-18T08:00:00.000Z',
        },
    ];
    const databaseListings = [
        createListing('db-visible-1'),
        createListing('db-owned', { isOwnedByViewer: true }),
        createListing('db-visible-2'),
    ];
    const fallbackListings = [createListing(7)];
    const result = (0, listingFavoriteKeys_js_1.buildSavedListingsPayload)(favorites, databaseListings, fallbackListings);
    strict_1.default.deepEqual(result.listings.map((listing) => String(listing.id)), ['db-visible-2', '7', 'db-visible-1']);
    strict_1.default.deepEqual(result.savedKeys, [
        'database:db-visible-2',
        'builtin:7',
        'database:db-visible-1',
    ]);
    strict_1.default.deepEqual(result.favorites.map((favorite) => favorite.listingId), ['db-visible-2', '7', 'db-visible-1']);
});
(0, node_test_1.default)('does not offer a favorite save control for known own database listings', () => {
    const listing = createListing('db-owned', {
        isOwnedByViewer: true,
    });
    const reference = (0, listingFavoriteKeys_js_1.getListingFavoriteReference)(listing);
    strict_1.default.equal((0, listingFavoriteKeys_js_1.isKnownOwnDatabaseFavoriteListing)(listing, reference, 'viewer-1'), true);
    strict_1.default.equal((0, listingFavoriteKeys_js_1.canOfferListingFavoriteControl)({
        listing,
        reference,
        isSaved: false,
        currentViewerId: 'viewer-1',
    }), false);
});
(0, node_test_1.default)('hides new database saves when viewer ownership is unavailable', () => {
    const listing = createListing('db-unknown-owner', {
        viewerOwnershipUnavailable: true,
    });
    const reference = (0, listingFavoriteKeys_js_1.getListingFavoriteReference)(listing);
    strict_1.default.equal((0, listingFavoriteKeys_js_1.canOfferListingFavoriteControl)({
        listing,
        reference,
        isSaved: false,
        currentViewerId: 'viewer-1',
    }), false);
    strict_1.default.equal((0, listingFavoriteKeys_js_1.canOfferListingFavoriteControl)({
        listing,
        reference,
        isSaved: true,
        currentViewerId: 'viewer-1',
    }), true);
});
(0, node_test_1.default)('allows builtin and known non-owned database favorite controls', () => {
    const builtinListing = createListing(9);
    const databaseListing = createListing('db-visible');
    strict_1.default.equal((0, listingFavoriteKeys_js_1.canOfferListingFavoriteControl)({
        listing: builtinListing,
        reference: (0, listingFavoriteKeys_js_1.getListingFavoriteReference)(builtinListing),
        isSaved: false,
        currentViewerId: 'viewer-1',
    }), true);
    strict_1.default.equal((0, listingFavoriteKeys_js_1.canOfferListingFavoriteControl)({
        listing: databaseListing,
        reference: (0, listingFavoriteKeys_js_1.getListingFavoriteReference)(databaseListing),
        isSaved: false,
        currentViewerId: 'viewer-1',
    }), true);
});
(0, node_test_1.default)('maps favorite save-validation RPC outcomes to distinct reasons', () => {
    strict_1.default.deepEqual((0, listingFavoriteKeys_js_1.getRpcFavoriteSaveValidationResult)(true), { ok: true });
    strict_1.default.deepEqual((0, listingFavoriteKeys_js_1.getRpcFavoriteSaveValidationResult)(false), {
        ok: false,
        reason: 'invalid-listing',
    });
    strict_1.default.deepEqual((0, listingFavoriteKeys_js_1.getRpcFavoriteSaveValidationResult)(null, 'PGRST202'), {
        ok: false,
        reason: 'schema-unavailable',
    });
    strict_1.default.deepEqual((0, listingFavoriteKeys_js_1.getRpcFavoriteSaveValidationResult)(null, '42883'), {
        ok: false,
        reason: 'schema-unavailable',
    });
    strict_1.default.deepEqual((0, listingFavoriteKeys_js_1.getRpcFavoriteSaveValidationResult)(null, '42501'), {
        ok: false,
        reason: 'database-unavailable',
    });
});
