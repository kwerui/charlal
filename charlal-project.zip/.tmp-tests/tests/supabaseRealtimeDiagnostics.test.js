"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strict_1 = __importDefault(require("node:assert/strict"));
const node_fs_1 = require("node:fs");
const node_test_1 = __importDefault(require("node:test"));
(0, node_test_1.default)('browser Supabase client does not override realtime transport', () => {
    const clientSource = (0, node_fs_1.readFileSync)('src/lib/supabase/client.ts', 'utf8');
    strict_1.default.equal(clientSource.includes('transport:'), false);
    strict_1.default.equal(clientSource.includes('createRealtimeDiagnosticTransport'), false);
});
(0, node_test_1.default)('realtime diagnostics do not persistently monkey-patch Supabase internals', () => {
    const diagnosticsSource = (0, node_fs_1.readFileSync)('src/lib/supabase/realtimeDiagnostics.ts', 'utf8');
    strict_1.default.equal(diagnosticsSource.includes('.realtime.connect ='), false);
    strict_1.default.equal(diagnosticsSource.includes('.realtime.disconnect ='), false);
    strict_1.default.equal(diagnosticsSource.includes('supabase.channel ='), false);
    strict_1.default.equal(diagnosticsSource.includes('supabase.removeChannel ='), false);
    strict_1.default.equal(diagnosticsSource.includes('window.__charlal'), false);
});
