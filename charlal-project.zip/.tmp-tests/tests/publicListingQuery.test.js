"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strict_1 = __importDefault(require("node:assert/strict"));
const node_test_1 = __importDefault(require("node:test"));
const publicListingQuery_js_1 = require("../src/lib/publicListingQuery.js");
(0, node_test_1.default)('normalizes listing query options for bounded category queries', () => {
    strict_1.default.deepEqual((0, publicListingQuery_js_1.normalizePublicListingQueryOptions)({
        categorySlug: ' marketplace ',
        subcategorySlug: ' buy ',
        minPrice: '1000',
        maxPrice: '5000',
        marketplaceType: ' used ',
        searchQuery: ' phone ',
        limit: 12,
    }), {
        categorySlug: 'marketplace',
        subcategorySlug: 'buy',
        isAllPage: false,
        housingTransaction: 'all',
        housingPropertyType: 'all',
        marketplaceType: 'used',
        minPrice: 1000,
        maxPrice: 5000,
        searchQuery: 'phone',
        limit: 12,
    });
});
(0, node_test_1.default)('ignores subcategory filtering for all category pages', () => {
    strict_1.default.equal((0, publicListingQuery_js_1.normalizePublicListingQueryOptions)({
        categorySlug: 'auto',
        subcategorySlug: 'all',
        isAllPage: true,
    }).subcategorySlug, '');
});
(0, node_test_1.default)('clamps invalid or oversized limits', () => {
    strict_1.default.equal((0, publicListingQuery_js_1.normalizePublicListingQueryOptions)({ limit: -1 }).limit, undefined);
    strict_1.default.equal((0, publicListingQuery_js_1.normalizePublicListingQueryOptions)({ limit: 500 }).limit, 100);
});
(0, node_test_1.default)('detects only meaningful search queries', () => {
    strict_1.default.equal((0, publicListingQuery_js_1.hasPublicListingSearchQuery)({ searchQuery: '   ' }), false);
    strict_1.default.equal((0, publicListingQuery_js_1.hasPublicListingSearchQuery)({ searchQuery: 'bike' }), true);
});
(0, node_test_1.default)('escapes user search text for PostgREST ilike filters', () => {
    strict_1.default.equal((0, publicListingQuery_js_1.toPublicListingIlikePattern)('  50% off_(today), please  '), '%50\\% off\\_ today please%');
});
