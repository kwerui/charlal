"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strict_1 = __importDefault(require("node:assert/strict"));
const node_test_1 = __importDefault(require("node:test"));
const messageThreadClientBehavior_js_1 = require("../src/lib/messageThreadClientBehavior.js");
(0, node_test_1.default)('detects whether the message thread is near the bottom', () => {
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.getScrollBottomDistance)({
        scrollHeight: 1000,
        clientHeight: 400,
        scrollTop: 520,
    }), 80);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.isNearMessageThreadBottom)({
        scrollHeight: 1000,
        clientHeight: 400,
        scrollTop: 520,
    }), true);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.isNearMessageThreadBottom)({
        scrollHeight: 1000,
        clientHeight: 400,
        scrollTop: 300,
    }), false);
});
(0, node_test_1.default)('auto-scrolls own messages even when the reader is not near the bottom', () => {
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.shouldAutoScrollForThreadMessage)({
        senderId: 'current-user',
        currentUserId: 'current-user',
        wasNearBottom: false,
    }), true);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.shouldAutoScrollForThreadMessage)({
        senderId: 'other-user',
        currentUserId: 'current-user',
        wasNearBottom: false,
    }), false);
});
(0, node_test_1.default)('starts thread realtime only after client auth is restored for this user', () => {
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.canStartThreadRealtime)({
        authStatus: 'checking',
        authUserId: null,
        currentUserId: 'current-user',
        isBrowserOnline: true,
    }), false);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.canStartThreadRealtime)({
        authStatus: 'authenticated',
        authUserId: 'different-user',
        currentUserId: 'current-user',
        isBrowserOnline: true,
    }), false);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.canStartThreadRealtime)({
        authStatus: 'authenticated',
        authUserId: 'current-user',
        currentUserId: 'current-user',
        isBrowserOnline: true,
    }), true);
});
(0, node_test_1.default)('caps thread realtime retry delays at the maximum configured delay', () => {
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.getThreadRealtimeRetryDelayMs)(0), 1000);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.getThreadRealtimeRetryDelayMs)(1), 3000);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.getThreadRealtimeRetryDelayMs)(99), 15000);
});
(0, node_test_1.default)('maps app channel names to Supabase realtime topics and counts duplicates', () => {
    const topic = (0, messageThreadClientBehavior_js_1.toSupabaseRealtimeTopic)('messaging-thread:conversation-1');
    strict_1.default.equal(topic, 'realtime:messaging-thread:conversation-1');
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.countRealtimeChannelsForTopic)([
        { topic },
        { topic: 'realtime:messaging-global:user-1' },
        { topic },
    ], topic), 2);
});
(0, node_test_1.default)('uses generation-specific realtime topics to avoid stale same-topic cleanup', () => {
    const baseName = 'messaging-thread:conversation-1';
    const firstChannelName = (0, messageThreadClientBehavior_js_1.getRealtimeChannelName)(baseName, 1);
    const secondChannelName = (0, messageThreadClientBehavior_js_1.getRealtimeChannelName)(baseName, 2);
    const firstTopic = (0, messageThreadClientBehavior_js_1.toSupabaseRealtimeTopic)(firstChannelName);
    const secondTopic = (0, messageThreadClientBehavior_js_1.toSupabaseRealtimeTopic)(secondChannelName);
    strict_1.default.equal(firstChannelName, 'messaging-thread:conversation-1:g1');
    strict_1.default.equal(secondChannelName, 'messaging-thread:conversation-1:g2');
    strict_1.default.notEqual(firstTopic, secondTopic);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.countRealtimeChannelsForTopic)([{ topic: firstTopic }, { topic: secondTopic }], firstTopic), 1);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.countRealtimeChannelsForTopicPrefix)([{ topic: firstTopic }, { topic: secondTopic }], (0, messageThreadClientBehavior_js_1.toSupabaseRealtimeTopic)(`${baseName}:`)), 2);
});
(0, node_test_1.default)('hydrates snapshots for attachment events or message events without attachments', () => {
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.shouldHydrateRealtimeMessageSnapshot)({
        eventTable: 'messages',
        rawEventIncludesAttachments: true,
    }), false);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.shouldHydrateRealtimeMessageSnapshot)({
        eventTable: 'messages',
        rawEventIncludesAttachments: false,
    }), true);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.shouldHydrateRealtimeMessageSnapshot)({
        eventTable: 'message_attachments',
        rawEventIncludesAttachments: false,
    }), true);
});
(0, node_test_1.default)('thread realtime joins only conversation-scoped message and read tables', () => {
    const specs = (0, messageThreadClientBehavior_js_1.getThreadRealtimePostgresChangeSpecs)('conversation-1');
    strict_1.default.deepEqual(specs.map((spec) => `${spec.table}:${spec.event}:${spec.filter}`), [
        'messages:INSERT:conversation_id=eq.conversation-1',
        'messages:UPDATE:conversation_id=eq.conversation-1',
        'conversation_reads:INSERT:conversation_id=eq.conversation-1',
        'conversation_reads:UPDATE:conversation_id=eq.conversation-1',
    ]);
    strict_1.default.equal(specs.map((spec) => String(spec.table)).includes('message_attachments'), false);
});
(0, node_test_1.default)('retries one-message hydration only for new messages with no attachments yet', () => {
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.getMessageSnapshotHydrationRetryDelayMs)(0), 750);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.getMessageSnapshotHydrationRetryDelayMs)(1), 2000);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.getMessageSnapshotHydrationRetryDelayMs)(2), null);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.shouldRetryMessageSnapshotHydration)({
        reason: 'message-insert',
        attachmentCount: 0,
        retryAttemptIndex: 0,
    }), true);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.shouldRetryMessageSnapshotHydration)({
        reason: 'message-update',
        attachmentCount: 0,
        retryAttemptIndex: 0,
    }), false);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.shouldRetryMessageSnapshotHydration)({
        reason: 'message-insert',
        attachmentCount: 1,
        retryAttemptIndex: 0,
    }), false);
    strict_1.default.equal((0, messageThreadClientBehavior_js_1.shouldRetryMessageSnapshotHydration)({
        reason: 'message-insert',
        attachmentCount: 0,
        retryAttemptIndex: 2,
    }), false);
});
