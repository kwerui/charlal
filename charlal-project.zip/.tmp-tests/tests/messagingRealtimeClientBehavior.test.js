"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strict_1 = __importDefault(require("node:assert/strict"));
const node_test_1 = __importDefault(require("node:test"));
const messagingRealtimeClientBehavior_js_1 = require("../src/lib/messagingRealtimeClientBehavior.js");
(0, node_test_1.default)('server snapshot refresh does not mark realtime subscribed', () => {
    strict_1.default.equal((0, messagingRealtimeClientBehavior_js_1.getMessagingRealtimeStatusAfterSnapshotRefresh)('idle'), 'idle');
    strict_1.default.equal((0, messagingRealtimeClientBehavior_js_1.getMessagingRealtimeStatusAfterSnapshotRefresh)('reconnecting'), 'reconnecting');
    strict_1.default.equal((0, messagingRealtimeClientBehavior_js_1.getMessagingRealtimeStatusAfterSnapshotRefresh)('unavailable'), 'unavailable');
});
(0, node_test_1.default)('only the actual subscribed callback marks messaging realtime healthy', () => {
    strict_1.default.equal((0, messagingRealtimeClientBehavior_js_1.getMessagingRealtimeStatusAfterSubscriptionStatus)({
        nextStatus: 'SUBSCRIBED',
        hadSubscribed: false,
    }), 'subscribed');
    strict_1.default.equal((0, messagingRealtimeClientBehavior_js_1.getMessagingRealtimeStatusAfterSubscriptionStatus)({
        nextStatus: 'TIMED_OUT',
        hadSubscribed: false,
    }), 'unavailable');
    strict_1.default.equal((0, messagingRealtimeClientBehavior_js_1.getMessagingRealtimeStatusAfterSubscriptionStatus)({
        nextStatus: 'CHANNEL_ERROR',
        hadSubscribed: true,
    }), 'unavailable');
    strict_1.default.equal((0, messagingRealtimeClientBehavior_js_1.getMessagingRealtimeStatusAfterSubscriptionStatus)({
        nextStatus: 'CLOSED',
        hadSubscribed: true,
    }), 'reconnecting');
});
