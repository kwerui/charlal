"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strict_1 = __importDefault(require("node:assert/strict"));
const node_fs_1 = require("node:fs");
const node_test_1 = __importDefault(require("node:test"));
(0, node_test_1.default)('root layout does not perform request-specific auth or unread-message work', () => {
    const layoutSource = (0, node_fs_1.readFileSync)('src/app/layout.tsx', 'utf8');
    strict_1.default.equal(layoutSource.includes('@/lib/auth/server'), false);
    strict_1.default.equal(layoutSource.includes('@/lib/supabase/messagingServer'), false);
    strict_1.default.equal(layoutSource.includes('getCurrentUserResult'), false);
    strict_1.default.equal(layoutSource.includes('countCurrentUserUnreadConversations'), false);
});
