"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strict_1 = __importDefault(require("node:assert/strict"));
const node_fs_1 = require("node:fs");
const node_test_1 = __importDefault(require("node:test"));
(0, node_test_1.default)('favorite toggles do not refresh the current route after mutation', () => {
    const buttonSource = (0, node_fs_1.readFileSync)('src/app/components/FavoriteListingButton.tsx', 'utf8');
    strict_1.default.equal(buttonSource.includes('router.refresh('), false);
});
(0, node_test_1.default)('favorite actions do not revalidate account owned-listing data', () => {
    const actionsSource = (0, node_fs_1.readFileSync)('src/app/favorites/actions.ts', 'utf8');
    strict_1.default.equal(actionsSource.includes("'/account'"), false);
    strict_1.default.equal(actionsSource.includes('listOwnedDatabaseListings'), false);
    strict_1.default.equal(actionsSource.includes('list_my_listings'), false);
});
(0, node_test_1.default)('saved listings use the bounded database listing lookup', () => {
    const favoritesSource = (0, node_fs_1.readFileSync)('src/lib/supabase/listingFavorites.ts', 'utf8');
    strict_1.default.equal(favoritesSource.includes('listPublicDatabaseListingsByIds'), true);
    strict_1.default.equal(favoritesSource.includes('listPublicDatabaseListings()'), false);
    strict_1.default.equal(favoritesSource.includes("rpc('list_my_listings'"), false);
});
(0, node_test_1.default)('favorite save validation does not bypass missing RPCs with owner_id reads', () => {
    const favoritesSource = (0, node_fs_1.readFileSync)('src/lib/supabase/listingFavorites.ts', 'utf8');
    const favoriteKeysSource = (0, node_fs_1.readFileSync)('src/lib/listingFavoriteKeys.ts', 'utf8');
    strict_1.default.equal(favoritesSource.includes(".select('id, owner_id, status')"), false);
    strict_1.default.equal(favoritesSource.includes('getRpcFavoriteSaveValidationResult'), true);
    strict_1.default.equal(favoriteKeysSource.includes('schema-unavailable'), true);
});
