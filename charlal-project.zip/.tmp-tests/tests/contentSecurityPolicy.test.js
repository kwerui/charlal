"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strict_1 = __importDefault(require("node:assert/strict"));
const node_test_1 = __importDefault(require("node:test"));
const next_config_js_1 = require("../next.config.js");
(0, node_test_1.default)('allows the exact Supabase HTTPS and Realtime WebSocket origins', () => {
    strict_1.default.deepEqual((0, next_config_js_1.getContentSecurityPolicyConnectSources)('https://example.supabase.co'), [
        "'self'",
        'https://example.supabase.co',
        'wss://example.supabase.co',
    ]);
});
(0, node_test_1.default)('derives a local Supabase websocket origin from an HTTP URL', () => {
    strict_1.default.deepEqual((0, next_config_js_1.getContentSecurityPolicyConnectSources)('http://127.0.0.1:54321'), [
        "'self'",
        'http://127.0.0.1:54321',
        'ws://127.0.0.1:54321',
    ]);
});
(0, node_test_1.default)('does not broaden websocket access when Supabase URL is invalid', () => {
    const connectSources = (0, next_config_js_1.getContentSecurityPolicyConnectSources)('not-a-url');
    strict_1.default.deepEqual(connectSources, ["'self'"]);
    strict_1.default.equal(connectSources.includes('wss:'), false);
    strict_1.default.equal(connectSources.includes('ws:'), false);
    strict_1.default.equal(connectSources.includes('*'), false);
});
